/* Persistence layer: saves and restores progress with localStorage.
   Every read is validated; corrupt data is ignored safely. */

const STORAGE_KEY = "defeatThe10EvilsSave";
const STORAGE_VERSION = 1;

const Storage = {
    save(state) {
        try {
            const data = {
                version: STORAGE_VERSION,
                completedMissions: state.completedMissions,
                unlockedBadges: state.unlockedBadges
            };
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
            return true;
        } catch (error) {
            console.warn("Unable to save progress.", error);
            return false;
        }
    },

    load() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (!raw) {
                return null;
            }

            const data = JSON.parse(raw);
            if (!data || typeof data !== "object" || data.version !== STORAGE_VERSION) {
                return null;
            }
            if (!Array.isArray(data.completedMissions)) {
                return null;
            }

            const validIds = new Set(MISSIONS.map((m) => m.id));
            const completedMissions = [...new Set(data.completedMissions)]
                .filter((id) => Number.isInteger(id) && validIds.has(id));

            const unlockedBadges = Array.isArray(data.unlockedBadges)
                ? data.unlockedBadges.filter((b) => typeof b === "string")
                : [];

            return { completedMissions, unlockedBadges };
        } catch (error) {
            console.warn("Saved data was unreadable and has been ignored.", error);
            return null;
        }
    },

    clear() {
        try {
            localStorage.removeItem(STORAGE_KEY);
        } catch (error) {
            console.warn("Unable to clear saved progress.", error);
        }
    }
};
