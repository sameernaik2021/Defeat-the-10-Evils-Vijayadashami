/* UI layer: renders the game state. Makes no game-rule decisions. */

const UI = {
    el(id) {
        return document.getElementById(id);
    },

    renderMissionGrid(state) {
        const grid = this.el("mission-grid");
        grid.replaceChildren();

        MISSIONS.forEach((mission) => {
            const completed = Game.isCompleted(mission.id);

            const card = document.createElement("button");
            card.type = "button";
            card.className = completed ? "mission-card completed" : "mission-card";
            card.setAttribute(
                "aria-label",
                `${mission.name} challenge, ${mission.points} XP${completed ? ", completed" : ""}`
            );

            const icon = document.createElement("span");
            icon.className = "mission-icon";
            icon.setAttribute("aria-hidden", "true");
            icon.textContent = mission.icon;

            const name = document.createElement("span");
            name.className = "mission-name";
            name.textContent = mission.name;

            const status = document.createElement("span");
            status.className = "mission-status";
            status.textContent = completed ? "Defeated ✓" : `${mission.points} XP`;

            card.append(icon, name, status);
            card.addEventListener("click", () => App.selectMission(mission.id));
            grid.appendChild(card);
        });
    },

    renderDashboard() {
        const count = Game.completedCount;
        this.el("score").textContent = `${Game.score} XP`;
        this.el("progress-text").textContent = `${count} / ${TOTAL_MISSIONS}`;
        this.el("progress-bar").value = count;
    },

    renderBadges() {
        const list = this.el("badge-list");
        list.replaceChildren();

        if (Game.state.unlockedBadges.length === 0) {
            const li = document.createElement("li");
            li.className = "empty";
            li.textContent = "No achievements yet. Defeat your first evil!";
            list.appendChild(li);
            return;
        }

        Game.state.unlockedBadges.forEach((badge) => {
            const li = document.createElement("li");
            li.textContent = `🏅 ${badge}`;
            list.appendChild(li);
        });
    },

    /* Shows the mission grid, hides everything else. */
    showMissionView() {
        this.el("mission-section").hidden = false;
        this.el("mission-details").hidden = true;
        this.el("victory-screen").hidden = true;
    },

    showMissionDetails(mission) {
        this.el("mission-section").hidden = true;
        this.el("victory-screen").hidden = true;
        this.el("mission-details").hidden = false;

        this.el("mission-title").textContent = `${mission.icon} ${mission.name} Challenge`;
        this.el("mission-type").textContent = this.typeLabel(mission.type);
        this.el("mission-description").textContent =
            `${mission.description} Reward: ${mission.reward}.`;

        const done = Game.isCompleted(mission.id);

        this.el("challenge-simple").hidden = mission.type !== "reflection";
        this.el("challenge-quiz").hidden = mission.type !== "quiz";
        this.el("challenge-pledge").hidden = mission.type !== "pledge";

        if (mission.type === "reflection") {
            const btn = this.el("complete-button");
            btn.disabled = done;
            btn.textContent = done ? "Already Defeated ✓" : "Complete Challenge";
        }

        if (mission.type === "quiz") {
            this.renderQuiz(mission, done);
        }

        if (mission.type === "pledge") {
            this.el("pledge-text").textContent = mission.pledgeText;
            const checkbox = this.el("pledge-checkbox");
            checkbox.checked = done;
            checkbox.disabled = done;
            this.el("pledge-button").disabled = done;
            this.el("pledge-button").textContent = done ? "Already Defeated ✓" : "Submit Pledge";
        }

        this.setFeedback("");
    },

    renderQuiz(mission, done) {
        this.el("quiz-question").textContent = mission.question;
        this.el("quiz-feedback").textContent = "";
        this.el("quiz-feedback").className = "quiz-feedback";

        const container = this.el("quiz-options");
        container.replaceChildren();

        mission.options.forEach((option, index) => {
            const btn = document.createElement("button");
            btn.type = "button";
            btn.textContent = option;
            btn.disabled = done;
            btn.addEventListener("click", () => App.answerQuiz(mission.id, index));
            container.appendChild(btn);
        });
    },

    markQuizAnswer(index, correct) {
        const buttons = this.el("quiz-options").querySelectorAll("button");
        if (correct && buttons[index]) {
            buttons[index].disabled = true;
        }
    },

    setFeedback(message, type = "") {
        this.el("game-status").textContent = message;
        const quizFeedback = this.el("quiz-feedback");
        if (quizFeedback && !this.el("challenge-quiz").hidden) {
            quizFeedback.textContent = message;
            quizFeedback.className = `quiz-feedback ${type}`.trim();
        }
    },

    typeLabel(type) {
        return {
            reflection: "Reflection Challenge",
            quiz: "Knowledge Quiz",
            pledge: "Personal Pledge"
        }[type] || "Challenge";
    },

    showToast(message) {
        const toast = this.el("toast");
        toast.textContent = message;
        toast.hidden = false;
        toast.classList.remove("show");
        void toast.offsetWidth; // restart animation
        toast.classList.add("show");

        clearTimeout(this._toastTimer);
        this._toastTimer = setTimeout(() => {
            toast.hidden = true;
        }, 3000);
    },

    flashCard(missionId) {
        const cards = this.el("mission-grid").querySelectorAll(".mission-card");
        const index = MISSIONS.findIndex((m) => m.id === missionId);
        const card = cards[index];
        if (card) {
            card.classList.add("just-completed");
            card.addEventListener("animationend", () => {
                card.classList.remove("just-completed");
            }, { once: true });
        }
    },

    showVictory() {
        this.el("mission-section").hidden = true;
        this.el("mission-details").hidden = true;
        this.el("victory-screen").hidden = false;
        this.el("final-score").textContent = `Your final score: ${Game.score} XP`;
        this.el("victory-screen").focus?.();
    },

    renderAll() {
        this.renderMissionGrid();
        this.renderDashboard();
        this.renderBadges();
    }
};
