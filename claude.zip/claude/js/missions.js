/* Mission data: the single source of mission definitions.
   Types: "reflection" (activity confirmed by player),
          "quiz" (correct answer required),
          "pledge" (checkbox commitment required). */

const TOTAL_MISSIONS = 10;
const POINTS_PER_MISSION = 100;

const MISSIONS = [
    {
        id: 1,
        name: "Anger",
        icon: "🔥",
        type: "reflection",
        description: "Take five slow breaths and reflect on how a calm response can change a difficult situation.",
        reward: "Wisdom Shield",
        points: POINTS_PER_MISSION
    },
    {
        id: 2,
        name: "Ego",
        icon: "👑",
        type: "reflection",
        description: "Think of something valuable you learned from another person.",
        reward: "Humility Badge",
        points: POINTS_PER_MISSION
    },
    {
        id: 3,
        name: "Greed",
        icon: "💰",
        type: "reflection",
        description: "Identify one meaningful way to share, give, or help.",
        reward: "Generosity Emblem",
        points: POINTS_PER_MISSION
    },
    {
        id: 4,
        name: "Jealousy",
        icon: "💚",
        type: "reflection",
        description: "Write down three things you appreciate in your own life.",
        reward: "Gratitude Star",
        points: POINTS_PER_MISSION
    },
    {
        id: 5,
        name: "Laziness",
        icon: "💤",
        type: "reflection",
        description: "Complete one small, useful task you have been postponing.",
        reward: "Action Medal",
        points: POINTS_PER_MISSION
    },
    {
        id: 6,
        name: "Dishonesty",
        icon: "🤝",
        type: "pledge",
        description: "Make a personal pledge to communicate honestly and responsibly.",
        pledgeText: "I will try to communicate honestly and responsibly.",
        reward: "Truth Emblem",
        points: POINTS_PER_MISSION
    },
    {
        id: 7,
        name: "Hatred",
        icon: "❤️",
        type: "reflection",
        description: "Reflect on how empathy can help you understand another person's perspective.",
        reward: "Empathy Heart",
        points: POINTS_PER_MISSION
    },
    {
        id: 8,
        name: "Arrogance",
        icon: "🦁",
        type: "reflection",
        description: "Recognize a contribution made by someone else.",
        reward: "Humility Laurel",
        points: POINTS_PER_MISSION
    },
    {
        id: 9,
        name: "Selfishness",
        icon: "🎁",
        type: "reflection",
        description: "Identify one helpful action you can perform without expecting a reward.",
        reward: "Kindness Badge",
        points: POINTS_PER_MISSION
    },
    {
        id: 10,
        name: "Ignorance",
        icon: "📚",
        type: "quiz",
        description: "Answer a question about the Ramayana and learn something new.",
        question: "Which festival celebrates the victory of good over evil and is widely associated with Rama's victory over Ravana?",
        options: ["Holi", "Vijayadashami", "Makar Sankranti", "Onam"],
        correctAnswer: 1,
        reward: "Knowledge Scroll",
        points: POINTS_PER_MISSION
    }
];

const ACHIEVEMENTS = [
    { threshold: 1,  name: "First Step" },
    { threshold: 3,  name: "Rising Hero" },
    { threshold: 5,  name: "Halfway Hero" },
    { threshold: 8,  name: "Virtue Seeker" },
    { threshold: 10, name: "Champion of Good" }
];
