/* App controller: wires user actions to Game logic, Storage, and UI.
   Load last: after missions.js, storage.js, game.js, ui.js. */

const App = {
    init() {
        const saved = Storage.load();
        if (saved) {
            Game.restore(saved);
        }

        this.bindEvents();
        UI.renderAll();

        if (Game.isComplete) {
            UI.showVictory();
        } else {
            UI.showMissionView();
        }
    },

    bindEvents() {
        UI.el("complete-button").addEventListener("click", () => {
            this.completeCurrent();
        });

        UI.el("pledge-button").addEventListener("click", () => {
            const checked = UI.el("pledge-checkbox").checked;
            if (!checked) {
                UI.setFeedback("Please tick the pledge box to confirm your commitment.");
                return;
            }
            this.completeCurrent();
        });

        UI.el("back-button").addEventListener("click", () => {
            Game.state.selectedMissionId = null;
            UI.showMissionView();
            UI.setFeedback("");
        });

        UI.el("restart-button").addEventListener("click", () => this.restart());
        UI.el("reset-button").addEventListener("click", () => this.restart());
    },

    selectMission(id) {
        const mission = Game.getMission(id);
        if (!mission) {
            return;
        }
        Game.state.selectedMissionId = id;
        UI.showMissionDetails(mission);
    },

    answerQuiz(id, selectedIndex) {
        const mission = Game.getMission(id);
        if (!mission || Game.isCompleted(id)) {
            return;
        }

        if (selectedIndex === mission.correctAnswer) {
            UI.markQuizAnswer(selectedIndex, true);
            UI.setFeedback("Correct! 🎉", "correct");
            this.completeMission(id);
        } else {
            UI.setFeedback(
                "Not quite. Think about the festival that marks Rama's victory, then try again.",
                "wrong"
            );
        }
    },

    completeCurrent() {
        const id = Game.state.selectedMissionId;
        if (id !== null) {
            this.completeMission(id);
        }
    },

    completeMission(id) {
        const result = Game.completeMission(id);
        if (!result) {
            return; // Already completed or invalid.
        }

        Storage.save(Game.state);

        const { mission, newBadges } = result;

        UI.renderMissionGrid();
        UI.renderDashboard();
        UI.renderBadges();
        UI.flashCard(id);

        if (Game.isComplete) {
            UI.showVictory();
            UI.showToast("🪔 All ten evils defeated! Champion of Good!");
            return;
        }

        const badgeText = newBadges.length
            ? ` Achievement unlocked: ${newBadges.join(", ")}!`
            : "";
        const message = `${mission.name} defeated! +${mission.points} XP. Reward: ${mission.reward}.${badgeText}`;

        UI.showToast(message);
        UI.setFeedback(message);

        // Return to the grid so the player can choose the next challenge.
        Game.state.selectedMissionId = null;
        UI.showMissionView();
        UI.setFeedback(message);
    },

    restart() {
        const confirmed = window.confirm(
            "Start a new game? Your saved progress will be cleared."
        );
        if (!confirmed) {
            return;
        }

        Game.reset();
        Storage.clear();
        UI.renderAll();
        UI.showMissionView();
        UI.setFeedback("New game started. Choose your first challenge.");
    }
};

document.addEventListener("DOMContentLoaded", () => App.init());
