/* Game logic: state, scoring, achievements, victory.
   Knows nothing about the DOM. */

const Game = {
    state: {
        score: 0,
        completedMissions: [],
        unlockedBadges: [],
        selectedMissionId: null
    },

    getMission(id) {
        return MISSIONS.find((m) => m.id === id) || null;
    },

    isCompleted(id) {
        return this.state.completedMissions.includes(id);
    },

    get completedCount() {
        return this.state.completedMissions.length;
    },

    get isComplete() {
        return this.completedCount === TOTAL_MISSIONS;
    },

    get score() {
        return this.state.completedMissions.reduce((total, id) => {
            const mission = this.getMission(id);
            return total + (mission ? mission.points : 0);
        }, 0);
    },

    /* Restore from saved data. Score and badges are derived, never trusted. */
    restore(saved) {
        this.state.completedMissions = saved.completedMissions.slice();
        this.state.selectedMissionId = null;
        this.updateAchievements();
        this.state.score = this.score;
    },

    /* Returns the list of newly unlocked badge names, or null if nothing changed. */
    completeMission(id) {
        const mission = this.getMission(id);
        if (!mission || this.isCompleted(id)) {
            return null; // Idempotent: no duplicate XP or rewards.
        }

        this.state.completedMissions.push(id);
        this.state.score = this.score;

        const before = this.state.unlockedBadges.slice();
        this.updateAchievements();
        const newBadges = this.state.unlockedBadges.filter((b) => !before.includes(b));

        return { mission, newBadges };
    },

    updateAchievements() {
        ACHIEVEMENTS.forEach((rule) => {
            if (this.completedCount >= rule.threshold &&
                !this.state.unlockedBadges.includes(rule.name)) {
                this.state.unlockedBadges.push(rule.name);
            }
        });
    },

    reset() {
        this.state.score = 0;
        this.state.completedMissions = [];
        this.state.unlockedBadges = [];
        this.state.selectedMissionId = null;
    }
};
