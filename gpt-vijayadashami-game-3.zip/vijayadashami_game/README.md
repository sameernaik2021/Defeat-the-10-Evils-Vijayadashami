# Vijayadashami — The Ten-Head Challenge

A responsive, family-friendly Vijayadashami browser game built with HTML, CSS, and vanilla JavaScript, inspired by the supplied `Dussehra.jpg` illustration.

## Gameplay
- Start from the welcome screen.
- Press **Release arrow** to shoot one arrow at a time.
- Each successful shot removes one of Ravana's ten heads.
- A progress bar tracks the 10-shot challenge.
- Defeating all ten heads unlocks an animated **Happy Vijayadashami!** celebration and the **Golden Arrow of Dharma** digital reward.
- Optional synthesized sound effects can be switched on or off.
- Restart or play again at any time.

## Run locally
1. Extract the ZIP while keeping the `assets/` directory beside the HTML file.
2. Open `index.html` in a modern browser (Firefox, Chrome, or Edge).
3. No server, npm install, API key, or internet connection is required for gameplay. The optional Google Fonts import falls back to system fonts when offline.

## Project structure
```text
vijayadashami-game/
├── index.html
├── styles.css
├── script.js
├── README.md
└── assets/
    ├── Dussehra.jpg
    └── ravana-head-01.jpg ... ravana-head-10.jpg
```

## Implementation notes
- Uses semantic HTML, responsive CSS, and plain JavaScript.
- No external JavaScript libraries or tracking.
- Does not collect personal data or require local storage.
- Optional audio uses the browser Web Audio API and only starts after the player enables sound.
- The supplied illustration is included as the welcome-screen artwork. Ten cropped head sprites are derived from the supplied image for the gameplay stage.

## Troubleshooting
- Keep the `assets` folder in the same directory as `index.html`; do not move the HTML file by itself.
- If sound is silent, check browser/site audio settings. The game remains playable without sound.
- For a completely offline look, remove the Google Fonts `@import` at the top of `styles.css`; local fallback fonts are included.
