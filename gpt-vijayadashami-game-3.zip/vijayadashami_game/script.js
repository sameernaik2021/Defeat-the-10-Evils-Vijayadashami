(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const intro = $("intro"), game = $("game"), startButton = $("startButton");
  const headRow = $("headRow"), shootButton = $("shootButton"), resetButton = $("resetButton");
  const progressText = $("progressText"), progressPercent = $("progressPercent");
  const progressFill = $("progressFill"), shotCount = $("shotCount"), stageToast = $("stageToast");
  const arrow = $("arrow"), celebration = $("celebration"), playAgain = $("playAgain");
  const soundToggle = $("soundToggle");
  let defeated = 0, busy = false, soundOn = false, audioContext = null;
  const totalHeads = 10;

  function buildHeads() {
    headRow.replaceChildren();
    for (let i = 1; i <= totalHeads; i++) {
      const head = document.createElement("img");
      head.className = "head-sprite";
      head.src = `assets/ravana-head-${String(i).padStart(2, "0")}.jpg`;
      head.alt = `Ravana head ${i}`;
      head.draggable = false;
      head.addEventListener("error", () => {
        head.alt = `Ravana head ${i} (artwork asset missing)`;
        head.style.background = "#f3a34b";
      });
      headRow.appendChild(head);
    }
  }
  function playTone(frequency = 620, duration = .12, type = "sine") {
    if (!soundOn) return;
    try {
      audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
      if (audioContext.state === "suspended") audioContext.resume();
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      oscillator.type = type;
      oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
      gain.gain.setValueAtTime(.08, audioContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(.001, audioContext.currentTime + duration);
      oscillator.connect(gain); gain.connect(audioContext.destination);
      oscillator.start(); oscillator.stop(audioContext.currentTime + duration);
    } catch (_) { /* Audio is optional; gameplay still works without it. */ }
  }
  function updateProgress() {
    const percent = Math.round(defeated / totalHeads * 100);
    progressText.textContent = `${defeated} of ${totalHeads} heads defeated`;
    progressPercent.textContent = `${percent}%`;
    progressFill.style.width = `${percent}%`;
    shotCount.textContent = totalHeads - defeated;
  }
  function resetGame() {
    defeated = 0; busy = false;
    celebration.classList.add("hidden");
    shootButton.disabled = false;
    shootButton.innerHTML = '<span class="bow-icon">➶</span><span>Release arrow</span>';
    stageToast.textContent = "Aim with courage!";
    arrow.style.transition = "none";
    arrow.style.transform = "rotate(-8deg) translateX(0)";
    void arrow.offsetWidth;
    arrow.style.transition = "";
    buildHeads(); updateProgress();
  }
  function startGame() {
    intro.classList.add("hidden"); game.classList.remove("hidden");
    resetGame();
    game.scrollIntoView({behavior:"smooth", block:"start"});
  }
  function shoot() {
    if (busy || defeated >= totalHeads) return;
    const heads = headRow.querySelectorAll(".head-sprite:not(.defeated)");
    if (!heads.length) return;
    busy = true; shootButton.disabled = true;
    stageToast.textContent = "Arrow released!";
    arrow.style.transform = "rotate(-8deg) translateX(175px)";
    playTone(360, .1, "triangle");
    window.setTimeout(() => {
      const target = heads[0];
      target.classList.add("hit");
      playTone(740, .16, "sine");
      window.setTimeout(() => {
        target.classList.add("defeated");
        defeated++;
        updateProgress();
        if (defeated < totalHeads) {
          stageToast.textContent = ["A brave shot!", "Courage and wisdom!", "Dharma grows stronger!", "One step closer to victory!"][defeated % 4];
          arrow.style.transition = "none";
          arrow.style.transform = "rotate(-8deg) translateX(0)";
          void arrow.offsetWidth;
          arrow.style.transition = "";
          busy = false; shootButton.disabled = false;
        } else {
          stageToast.textContent = "Good has triumphed over evil!";
          shootButton.innerHTML = '<span class="bow-icon">✦</span><span>Victory!</span>';
          playTone(880, .25); window.setTimeout(() => playTone(1100, .35), 180);
          window.setTimeout(() => celebration.classList.remove("hidden"), 650);
          busy = false;
        }
      }, 280);
    }, 360);
  }
  startButton.addEventListener("click", startGame);
  shootButton.addEventListener("click", shoot);
  resetButton.addEventListener("click", resetGame);
  playAgain.addEventListener("click", resetGame);
  soundToggle.addEventListener("click", () => {
    soundOn = !soundOn;
    soundToggle.setAttribute("aria-pressed", String(soundOn));
    soundToggle.innerHTML = soundOn ? "♫ <span>Sound on</span>" : "♫ <span>Sound off</span>";
    if (soundOn) playTone(660, .12);
  });
  buildHeads(); updateProgress();
})();