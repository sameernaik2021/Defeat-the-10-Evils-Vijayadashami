# Defeat the 10 Evils — A Vijayadashami Challenge

A responsive, browser-based educational game built with HTML, CSS and vanilla JavaScript. Players complete ten positive-habit challenges, earn XP, unlock milestone badges and become **Champion of Good**.

## Features

- Ten mission cards representing Anger, Ego, Greed, Jealousy, Laziness, Dishonesty, Hatred, Arrogance, Selfishness and Ignorance.
- Four interaction patterns: reflection, real-life activity, pledge and a Ramayana/Vijayadashami knowledge quiz.
- 100 XP per mission; maximum score is 1,000 XP. Duplicate mission rewards are prevented.
- Progress dashboard and milestone badges at 1, 3, 5, 8 and 10 missions.
- Victory screen and print-friendly certificate.
- Optional player name, responsive layout, keyboard-friendly controls, live status announcements and reduced-motion support.
- Local progress persistence with validation and graceful handling of unavailable or malformed browser storage.
- No framework, build step, server or third-party runtime dependency is required. A Google Fonts import is optional; system font fallbacks are included.

## Run the game

1. Extract the ZIP archive.
2. Open `index.html` in a current browser (Firefox, Chrome, Edge or Safari).
3. Enter an optional hero name and select **Begin the quest**.

For local development, you can also run a static server from the project directory, for example:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

## Project structure

```text
defeat-the-10-evils/
├── index.html
├── README.md
├── css/
│   └── style.css
└── js/
    ├── missions.js
    └── game.js
```

- `index.html` defines the screens, dialogs, semantic structure and accessibility landmarks.
- `css/style.css` defines the festive visual design, responsive grid, state styling, motion preferences and print styles.
- `js/missions.js` contains mission data only.
- `js/game.js` manages state, mission validation, XP, achievements, UI rendering and localStorage persistence.

## Gameplay rules

- Each mission is worth 100 XP and may be completed only once.
- The Ignorance mission is a quiz; only the correct answer completes it.
- Reflection and activity prompts require a short response. The honesty pledge requires checking the pledge box.
- Milestones: First Step (1), Rising Hero (3), Halfway Hero (5), Virtue Seeker (8), Champion of Good (10).
- Real-life activities are self-confirmed. The app cannot independently verify that an offline activity occurred.

## Persistence and privacy

The game saves only the optional player name, completed mission IDs and started state under the `defeatThe10Evils.v1` localStorage key. Reflection text is not saved or transmitted. Data remains in the current browser profile and is not synchronized between devices. Clearing browser storage removes progress. Browser storage can be edited by the player, so this offline version must not be used as the authoritative score source for competitions or verified certificates.

## Reset progress

Use **Start over** and confirm the prompt. This clears the saved game for this browser and returns to the welcome screen.

## Testing checklist

- [ ] Start a new game; all ten mission cards are visible.
- [ ] Complete a reflection or activity after entering a response; score rises by 100 XP.
- [ ] Try completing the same mission again; no extra XP is awarded.
- [ ] Try submitting the pledge without checking it; completion is blocked.
- [ ] Try an incorrect quiz answer; no points are awarded. Select the correct answer to complete the quiz.
- [ ] Verify badges unlock at 1, 3, 5, 8 and 10 missions.
- [ ] Refresh after completing a mission; progress is restored.
- [ ] Complete all ten missions; final score is 1,000 XP and Champion of Good is shown.
- [ ] Print the certificate and verify the print layout.
- [ ] Test keyboard navigation, reduced-motion preferences and narrow mobile widths.
- [ ] Try malformed or unavailable localStorage; the app should still start without crashing.

## Known limitations

- This is a single-player static web app. It has no account system, server-side validation, cross-device sync, organizer dashboard or online leaderboard.
- Player-entered reflections are intentionally not persisted.
- Browser storage is best-effort and may be blocked by browser privacy settings. For local-file usage, persistence behavior can vary by browser; a local static server is recommended if it does not save as expected.
- The printable certificate is a personal keepsake, not an independently verified credential.

## Technology

HTML5 · CSS3 · Vanilla JavaScript · Web Storage API · HTML Dialog API · Print CSS
