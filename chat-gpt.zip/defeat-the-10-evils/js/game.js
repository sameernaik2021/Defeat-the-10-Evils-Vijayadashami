(() => {
  'use strict';
  const missions = window.GAME_MISSIONS;
  const TOTAL = missions.length;
  const XP_PER_MISSION = 100;
  const STORAGE_KEY = 'defeatThe10Evils.v1';
  const achievementRules = [
    {threshold:1,name:'First Step',icon:'🌱'},
    {threshold:3,name:'Rising Hero',icon:'🌟'},
    {threshold:5,name:'Halfway Hero',icon:'🛡️'},
    {threshold:8,name:'Virtue Seeker',icon:'🪷'},
    {threshold:10,name:'Champion of Good',icon:'🪔'}
  ];
  const $ = (id) => document.getElementById(id);
  const state = {playerName:'',completed:[],started:false};
  let currentMissionId = null;
  let toastTimer = null;
  let lastFocus = null;

  const elements = {
    welcome:$('welcome-screen'), game:$('game-screen'), victory:$('victory-screen'),
    form:$('start-form'), playerName:$('player-name'), grid:$('mission-grid'),
    score:$('score'), progressText:$('progress-text'), progressBar:$('progress-bar'),
    progressFill:$('progress-fill'), progressCaption:$('progress-caption'), progressPercent:$('progress-percent'),
    badgeList:$('badge-list'), dialog:$('mission-dialog'), dialogContent:$('dialog-content'),
    rulesDialog:$('rules-dialog'), toast:$('toast')
  };

  function safeRead() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      const data = JSON.parse(raw);
      if (!data || typeof data !== 'object' || !Array.isArray(data.completed)) return null;
      const valid = new Set(missions.map(m => m.id));
      return {
        playerName: typeof data.playerName === 'string' ? data.playerName.slice(0,28) : '',
        completed: [...new Set(data.completed.filter(id => Number.isInteger(id) && valid.has(id)))],
        started: data.started === true
      };
    } catch (error) {
      console.warn('Saved game could not be read; starting with a clean state.', error);
      return null;
    }
  }
  function save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({playerName:state.playerName,completed:state.completed,started:state.started}));
    } catch (error) {
      console.warn('Progress could not be saved in this browser.', error);
      showToast('Progress could not be saved. Check your browser storage settings.');
    }
  }
  function completedCount() { return state.completed.length; }
  function score() { return completedCount() * XP_PER_MISSION; }
  function unlockedBadges() { return achievementRules.filter(rule => completedCount() >= rule.threshold); }
  function missionIsComplete(id) { return state.completed.includes(id); }

  function startGame(name) {
    state.playerName = (name || '').trim().slice(0,28);
    state.started = true;
    save();
    elements.welcome.hidden = true;
    elements.victory.hidden = true;
    elements.game.hidden = false;
    render();
    if (completedCount() === TOTAL) showVictory();
    $('game-title').focus?.();
  }
  function render() {
    renderCards(); renderDashboard(); renderBadges();
  }
  function renderCards() {
    elements.grid.replaceChildren();
    missions.forEach(mission => {
      const done = missionIsComplete(mission.id);
      const button = document.createElement('button');
      button.type = 'button';
      button.className = `mission-card${done ? ' completed' : ''}`;
      button.setAttribute('aria-label', `${mission.name} challenge, ${done ? 'completed' : '100 XP available'}`);
      button.setAttribute('aria-pressed','false');
      const icon = document.createElement('span'); icon.className='mission-icon'; icon.textContent=done?'✓':mission.icon; icon.setAttribute('aria-hidden','true');
      const number = document.createElement('span'); number.className='mission-number'; number.textContent=`CHALLENGE ${String(mission.id).padStart(2,'0')}`;
      const name = document.createElement('span'); name.className='mission-name'; name.textContent=mission.name;
      const virtue = document.createElement('span'); virtue.className='mission-virtue'; virtue.textContent=mission.virtue;
      const status = document.createElement('span'); status.className='mission-status'; status.textContent=done?'Completed ✓':`${XP_PER_MISSION} XP · Start`;
      button.append(icon,number,name,virtue,status);
      button.addEventListener('click', () => openMission(mission.id, button));
      elements.grid.append(button);
    });
  }
  function renderDashboard() {
    const count = completedCount(); const percent = Math.round(count / TOTAL * 100);
    elements.score.textContent = `${score().toLocaleString()} XP`;
    elements.progressText.textContent = `${count} / ${TOTAL}`;
    elements.progressBar.setAttribute('aria-valuenow', String(count));
    elements.progressFill.style.width = `${percent}%`;
    elements.progressPercent.textContent = `${percent}%`;
    elements.progressCaption.textContent = count === 0 ? 'Your first step awaits' : count === TOTAL ? 'All challenges completed!' : `${TOTAL-count} challenge${TOTAL-count===1?'':'s'} left to go`;
  }
  function renderBadges() {
    elements.badgeList.replaceChildren();
    achievementRules.forEach(rule => {
      const unlocked = completedCount() >= rule.threshold;
      const badge = document.createElement('div'); badge.className=`badge${unlocked?' unlocked':''}`;
      const icon=document.createElement('span'); icon.className='badge-icon'; icon.textContent=rule.icon;
      const title=document.createElement('strong'); title.textContent=rule.name;
      const note=document.createElement('small'); note.textContent=unlocked?'Unlocked':`${rule.threshold} mission${rule.threshold===1?'':'s'}`;
      badge.append(icon,title,note); elements.badgeList.append(badge);
    });
  }
  function make(tag, className, text) {
    const node=document.createElement(tag); if(className) node.className=className; if(text !== undefined) node.textContent=text; return node;
  }
  function openMission(id, focusTarget) {
    const mission=missions.find(item => item.id===id); if(!mission) return;
    if(missionIsComplete(id)) { showToast(`${mission.name} is already complete. Your XP is safe!`); return; }
    currentMissionId=id; lastFocus=focusTarget || document.activeElement;
    elements.dialogContent.replaceChildren();
    const hero=make('div','dialog-hero');
    hero.append(make('div','dialog-hero-icon',mission.icon));
    const titleWrap=make('div'); titleWrap.append(make('p','eyebrow','MISSION '+String(mission.id).padStart(2,'0'))); titleWrap.append(make('h2','',mission.name)); titleWrap.append(make('p','',`Practise ${mission.virtue.toLowerCase()}`)); hero.append(titleWrap);
    elements.dialogContent.append(hero,make('p','challenge-copy',mission.prompt));
    const box=make('div','challenge-box'); box.append(make('h3','',mission.type==='quiz'?'Knowledge check':mission.type==='pledge'?'Your pledge':mission.type==='reflection'?'Pause and reflect':'Put it into practice'));
    box.append(make('p','',mission.type==='quiz'?'Choose the correct answer to complete this mission.':mission.type==='pledge'?'Read the pledge, then check the box to confirm your intention.':'Take a moment to consider the prompt, then enter a short response or reflection.'));
    const form=make('form','challenge-form'); form.noValidate=true;
    if(mission.type==='quiz') {
      mission.options.forEach((option,index)=>{
        const label=make('label'); const input=document.createElement('input'); input.type='radio'; input.name='quiz-answer'; input.value=String(index); input.required=true;
        label.append(input,document.createTextNode(option)); form.append(label);
      });
    } else if(mission.type==='pledge') {
      const label=make('label'); const input=document.createElement('input'); input.type='checkbox'; input.name='pledge-confirm'; input.required=true;
      label.append(input,document.createTextNode(mission.question)); form.append(label);
    } else {
      const label=make('label','',mission.question); label.htmlFor='reflection-answer';
      const textarea=document.createElement('textarea'); textarea.id='reflection-answer'; textarea.name='reflection-answer'; textarea.maxLength=600; textarea.required=true; textarea.placeholder=mission.type==='reflection'?'Write a thought or intention (at least a few words)…':'Describe one small action you can take…'; textarea.setAttribute('aria-describedby','answer-help');
      form.append(label,textarea,make('small','fine-print','Your response stays in this browser only and is not sent anywhere.'));
    }
    const feedback=make('p','feedback'); feedback.hidden=true; feedback.setAttribute('role','status'); feedback.setAttribute('aria-live','polite');
    const submit=make('button','primary-button','Complete challenge · +100 XP'); submit.type='submit';
    form.append(submit,feedback); box.append(form); elements.dialogContent.append(box);
    const reward=make('div','reward-row'); reward.append(make('span','',`Reward · ${mission.reward}`),make('strong','',`+${XP_PER_MISSION} XP`)); elements.dialogContent.append(reward);
    form.addEventListener('submit',event => {
      event.preventDefault();
      const result=validateChallenge(mission,form);
      feedback.hidden=false; feedback.className=`feedback ${result.ok?'success':'error'}`; feedback.textContent=result.message;
      if(!result.ok) return;
      submit.disabled=true; submit.textContent='Challenge complete ✓';
      window.setTimeout(() => completeMission(mission), 550);
    });
    if(typeof elements.dialog.showModal==='function') elements.dialog.showModal(); else elements.dialog.setAttribute('open','');
    const first=elements.dialogContent.querySelector('textarea, input, button'); if(first) first.focus();
  }
  function validateChallenge(mission,form) {
    if(mission.type==='quiz') {
      const selected=form.querySelector('input[name="quiz-answer"]:checked');
      if(!selected) return {ok:false,message:'Choose an answer before continuing.'};
      if(Number(selected.value)!==mission.correctAnswer) return {ok:false,message:'Not quite. Try again—learning is part of the quest.'};
      return {ok:true,message:mission.explanation};
    }
    if(mission.type==='pledge') {
      const checked=form.querySelector('input[name="pledge-confirm"]');
      return checked && checked.checked ? {ok:true,message:'Pledge accepted. Thank you for making the commitment.'} : {ok:false,message:'Please check the pledge to confirm your intention.'};
    }
    const answer=form.querySelector('textarea');
    if(!answer || answer.value.trim().length<3) return {ok:false,message:'Please add a short response before completing this challenge.'};
    return {ok:true,message:'Reflection saved for this session. Well done for taking a thoughtful step.'};
  }
  function completeMission(mission) {
    if(!mission || missionIsComplete(mission.id)) return;
    const oldBadges=new Set(unlockedBadges().map(b=>b.name));
    state.completed.push(mission.id);
    state.completed=[...new Set(state.completed)];
    save(); render();
    if(elements.dialog.open) elements.dialog.close(); else elements.dialog.removeAttribute('open');
    const newBadges=unlockedBadges().filter(b=>!oldBadges.has(b.name));
    showToast(`${mission.icon} ${mission.name} complete! +${XP_PER_MISSION} XP${newBadges.length?` · ${newBadges.map(b=>b.name).join(', ')} unlocked`:''}`);
    currentMissionId=null;
    if(completedCount()===TOTAL) window.setTimeout(showVictory,450);
    if(lastFocus && typeof lastFocus.focus==='function') lastFocus.focus();
  }
  function showVictory() {
    elements.welcome.hidden=true; elements.game.hidden=true; elements.victory.hidden=false;
    $('victory-message').textContent=state.playerName ? `Well done, ${state.playerName}. You completed all ten challenges.` : 'You completed all ten challenges.';
    $('final-score').textContent=`${score().toLocaleString()} XP`;
    $('victory-badges').replaceChildren();
    unlockedBadges().forEach(b => $('victory-badges').append(make('span','',`${b.icon} ${b.name}`)));
    window.scrollTo({top:0,behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
  }
  function restart() {
    const ok=window.confirm('Start a new game? Your saved progress on this browser will be cleared.');
    if(!ok) return;
    state.playerName=''; state.completed=[]; state.started=false; currentMissionId=null;
    try { localStorage.removeItem(STORAGE_KEY); } catch(error) { console.warn('Could not clear saved game.',error); }
    elements.victory.hidden=true; elements.game.hidden=true; elements.welcome.hidden=false; elements.playerName.value='';
    render(); window.scrollTo({top:0,behavior:'smooth'}); $('player-name').focus();
  }
  function showToast(message) {
    elements.toast.textContent=message; elements.toast.classList.add('show');
    if(toastTimer) window.clearTimeout(toastTimer);
    toastTimer=window.setTimeout(()=>elements.toast.classList.remove('show'),3300);
  }
  function showRules() {
    if(typeof elements.rulesDialog.showModal==='function') elements.rulesDialog.showModal();
    else elements.rulesDialog.setAttribute('open','');
  }
  function printCertificate() { window.print(); }

  elements.form.addEventListener('submit',event=>{event.preventDefault();startGame(elements.playerName.value);});
  $('rules-button').addEventListener('click',showRules);
  $('restart-button').addEventListener('click',restart);
  $('victory-restart-button').addEventListener('click',restart);
  $('certificate-button').addEventListener('click',printCertificate);
  elements.dialog.addEventListener('close',()=>{if(lastFocus && document.contains(lastFocus)) lastFocus.focus();});
  elements.dialog.addEventListener('click',event=>{if(event.target===elements.dialog) elements.dialog.close();});
  elements.rulesDialog.addEventListener('click',event=>{if(event.target===elements.rulesDialog) elements.rulesDialog.close();});

  const saved=safeRead();
  if(saved) { state.playerName=saved.playerName; state.completed=saved.completed; state.started=saved.started; }
  render();
  if(state.started) startGame(state.playerName);
})();
