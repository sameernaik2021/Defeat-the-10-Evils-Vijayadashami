# Defeat the 10 Evils — A Vijayadashami Challenge

A self-contained educational Vijayadashami browser game built with HTML5, CSS3, and vanilla JavaScript.

## Run the game
1. Extract the ZIP archive.
2. Open `index.html` in a modern browser (Firefox, Chrome, Edge, or Safari).
3. No installation, server, external library, or internet connection is required.

## Gameplay
- Ten multiple-choice challenges inspired by the Ramayana, observation, puzzles, and good choices.
- Correct answers remove one of Ravana's ten illustrated heads.
- Incorrect answers reveal the correct answer and allow the player to retry.
- A progress bar and ten-head tracker show progress.
- Completing all challenges triggers an animated celebration, “Happy Vijayadashami!” greeting, and a claimable digital reward.
- Progress is saved locally in browser `localStorage` when available.
- Restart clears the saved game progress after confirmation.

## Files
- `index.html` — complete game markup, styling, illustration, game logic, challenge data, local persistence, and celebration.

## Compatibility
Designed for current desktop and mobile browsers. Uses standard HTML, CSS, and JavaScript. The game does not transmit data to a server. Saved progress remains in the browser on the current device. Clearing browser site data may erase it.

## Accessibility and resilience
- Responsive layout for narrow screens.
- Keyboard-focus indicators and status announcements.
- Reduced-motion preference is respected.
- Local storage failures are handled gracefully.

## Notes
Ravana is represented by a stylized CSS illustration in a theatrical festival-ground setting. This is a family-friendly educational game and not a depiction of a real event.
